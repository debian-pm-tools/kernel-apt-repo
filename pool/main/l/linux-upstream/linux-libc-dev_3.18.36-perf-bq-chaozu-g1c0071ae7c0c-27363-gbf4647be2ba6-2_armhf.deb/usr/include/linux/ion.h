#ifndef __UAPI_LINUX_ION_H__
#define __UAPI_LINUX_ION_H__

#include <linux/staging/android/uapi/ion.h>

#endif /* __UAPI_LINUX_ION_H__ */
