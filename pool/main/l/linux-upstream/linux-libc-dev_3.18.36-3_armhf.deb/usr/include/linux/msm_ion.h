#ifndef __UAPI_LINUX_MSM_ION_H__
#define __UAPI_LINUX_MSM_ION_H__

#include <linux/staging/android/uapi/msm_ion.h>

#endif /* __UAPI_LINUX_MSM_ION_H__ */
